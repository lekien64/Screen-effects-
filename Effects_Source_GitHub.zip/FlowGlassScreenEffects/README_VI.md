# Flow Glass Screen Effects – prototype 0.1

Ứng dụng Android mẫu giao diện Flow Glass, 4 hoạt ảnh tắt màn hình (CRT TV, thu nhỏ thành điểm, Fade Out, Glitch), thời lượng 600 ms.

## Giới hạn quan trọng
- Không khai báo Accessibility Service, không yêu cầu quyền Trợ năng.
- Không yêu cầu quyền quản trị thiết bị.
- Không Root.
- Chỉ khóa màn hình bằng nút trong ứng dụng. Không thể thay thế hoạt ảnh hệ thống khi nhấn nút nguồn vật lý trên HyperOS nếu không có hỗ trợ ở cấp ROM/System UI.
- Bản mẫu dùng API `Shizuku.newProcess` để gọi `input keyevent 26`. API này đã được Shizuku đánh dấu hướng chuyển sang UserService; cần kiểm thử trên ROM đích và có thể cần chuyển sang UserService ở bản ổn định.
- Đây là mã nguồn prototype, chưa phải APK đã biên dịch hoặc kiểm thử trên Xiaomi 17.

## Mở và build
1. Mở thư mục `FlowGlassScreenEffects` bằng Android Studio.
2. Chọn JDK 17.
3. Cho Gradle Sync tải plugin Android và Shizuku API từ Maven Central.
4. Build > Build APK(s).
5. Cài APK debug trên máy thử nghiệm.
6. Mở Shizuku, bảo đảm trạng thái Running.
7. Mở Flow Glass Screen Effects > Kết nối / cấp quyền Shizuku > chấp thuận.
8. Chọn hiệu ứng, thử Xem trước. Sau đó mới thử Hiệu ứng + Khóa màn hình.

## Quyền và an toàn
Ứng dụng không xin INTERNET, Accessibility, overlay, Device Admin hoặc quyền đọc dữ liệu. Chỉ cấp quyền Shizuku cho đúng ứng dụng này. Khi Shizuku dừng, tính năng khóa sẽ không hoạt động.

## Công nghệ
- Android Java, minSdk 26, compileSdk 35
- Shizuku API/provider 13.1.5
- Package: `com.flowglass.screeneffects`
