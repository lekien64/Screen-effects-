# Flow Glass Screen Effects — Device Admin 0.2

Ứng dụng Android minh họa bốn hoạt ảnh tắt màn hình Flow Glass: CRT TV, thu nhỏ thành điểm, Fade Out và Glitch. Thời lượng mỗi hoạt ảnh là 300 ms (0,3 giây).

## Quyền và cách hoạt động

- Không tích hợp Shizuku, không chạy lệnh ADB, không dùng Accessibility Service và không yêu cầu root.
- Dùng Android Device Administrator với đúng chính sách `force-lock` để gọi `DevicePolicyManager.lockNow()`.
- Người dùng phải tự xác nhận kích hoạt quyền quản trị thiết bị trong màn hình hệ thống.
- Nút xem trước chỉ phát hoạt ảnh. Nút “HIỆU ỨNG + KHÓA MÀN HÌNH” phát hoạt ảnh 300 ms trong ứng dụng rồi yêu cầu Android khóa màn hình.

## Giới hạn

Hoạt ảnh 300 ms là hoạt ảnh trong cửa sổ ứng dụng trước khi khóa, không thay thế được hoạt ảnh khóa/tắt màn hình của HyperOS khi nhấn nút nguồn vật lý. Việc ứng dụng ngân hàng/VNeID chấp nhận thiết bị có thể khác nhau theo chính sách từng ứng dụng; không thể cam kết chỉ riêng việc bỏ Shizuku sẽ bảo đảm tương thích.

## Thu hồi quyền

Vào Cài đặt > Bảo mật/Quyền riêng tư > Ứng dụng quản trị thiết bị (tên mục có thể khác trên HyperOS), chọn Flow Glass Screen Effects và tắt quyền. Sau đó có thể gỡ ứng dụng.
