# ScreenEffects 0.2 — Device Admin (không Shizuku)

- Giao diện Flow Glass được giữ lại.
- Thời lượng hiệu ứng: 300 ms (0,3 giây).
- Bỏ phụ thuộc Shizuku, ADB shell và Trợ năng.
- Dùng Android Device Administrator với chính sách duy nhất `force-lock`.
- Người dùng phải tự xác nhận kích hoạt quyền quản trị thiết bị.
- Nút “HIỆU ỨNG + KHÓA MÀN HÌNH” chạy hiệu ứng trong ứng dụng, sau đó gọi `DevicePolicyManager.lockNow()`.

## Giới hạn quan trọng

Hiệu ứng 300 ms là hoạt ảnh hiển thị bên trong ứng dụng trước khi gọi khóa màn hình. `DevicePolicyManager.lockNow()` không cho ứng dụng thay thế hoạt ảnh tắt màn hình của HyperOS khi nhấn nút nguồn vật lý. Device Admin cũng không bảo đảm mọi ứng dụng ngân hàng/VNeID đều chấp nhận thiết bị; hãy thử chính sách của từng ứng dụng và thu hồi quyền nếu cần.

## Thu hồi quyền

Cài đặt Android > Bảo mật / Quyền riêng tư > Ứng dụng quản trị thiết bị (tên mục có thể khác trên HyperOS) > Flow Glass Screen Effects > Tắt quyền. Sau đó có thể gỡ ứng dụng.
