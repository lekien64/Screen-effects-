# Build APK trên GitHub (không cần Android Studio)

## Cách làm bằng điện thoại

1. Đăng nhập GitHub tại https://github.com/ và tạo repository mới, ví dụ `FlowGlassScreenEffects`.
2. Giải nén `FlowGlassScreenEffects_Source_GitHub.zip` trên điện thoại.
3. Mở repository trên GitHub → **Add file** → **Upload files**.
4. Tải lên toàn bộ NỘI DUNG bên trong thư mục `FlowGlassScreenEffects` (bao gồm thư mục `.github`). Không tải nguyên thư mục bọc bên ngoài khiến `settings.gradle` nằm sâu thêm một cấp.
5. Nhập commit message `Add Flow Glass Screen Effects source` → **Commit changes**.
6. Mở tab **Actions** của repository. Workflow **Build Android APK** sẽ tự chạy sau khi push. Nếu chưa chạy, chọn workflow rồi nhấn **Run workflow**.
7. Mở lần chạy mới nhất ở trạng thái xanh **Success** → kéo xuống **Artifacts** → tải `FlowGlassScreenEffects-debug-apk`.
8. Giải nén artifact ZIP để lấy APK, sau đó cài trên điện thoại. Android có thể hỏi cho phép cài ứng dụng từ nguồn này.

## Nếu GitHub báo lỗi

Mở lần chạy trong tab Actions, chọn job `build`, sao chép phần log lỗi màu đỏ gửi lại để xử lý. Không chia sẻ token, mật khẩu hoặc khóa ký APK.

## Thông tin build

- GitHub Actions runner: Ubuntu
- JDK: 17
- Gradle: 8.9
- Android Gradle Plugin: 8.7.3
- Lệnh build: `gradle --no-daemon assembleDebug`
- APK đầu ra: `app/build/outputs/apk/debug/`

## Giới hạn prototype

Đây là APK debug chưa ký phát hành. Workflow chỉ biên dịch và lưu APK làm artifact; chưa cài hay kiểm thử trên Xiaomi 17. Bản hiện tại không khai báo Accessibility Service. Nút khóa trong app có thể chạy hiệu ứng trước khi gọi thao tác khóa qua Shizuku; không thể thay hiệu ứng hệ thống khi nhấn nút nguồn vật lý chỉ bằng Shizuku.
