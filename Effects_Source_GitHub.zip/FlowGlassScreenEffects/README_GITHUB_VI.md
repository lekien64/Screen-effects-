# Build ScreenEffects bằng GitHub Actions

Workflow `.github/workflows/android-build.yml` biên dịch APK debug bằng Java 17 và Gradle. Sau khi chạy thành công, tải artifact `ScreenEffects-APK` trong trang Actions.

Bản Device Admin này không dùng Shizuku, ADB shell hoặc Accessibility Service. Khi cài APK, người dùng phải tự kích hoạt quyền Quản trị viên thiết bị nếu muốn dùng nút khóa. Hoạt ảnh 0,3 giây chạy trong ứng dụng trước khi gọi `DevicePolicyManager.lockNow()`; nó không thay thế hoạt ảnh hệ thống khi nhấn nút nguồn vật lý. APK debug chưa ký phát hành và cần thử nghiệm thực tế trên Xiaomi 17 HyperOS 4.
