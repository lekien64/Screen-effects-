package com.flowglass.screeneffects;

import android.app.admin.DeviceAdminReceiver;

/** Receives Device Administrator activation state for the screen-lock action only. */
public class ScreenEffectsAdminReceiver extends DeviceAdminReceiver {
}
