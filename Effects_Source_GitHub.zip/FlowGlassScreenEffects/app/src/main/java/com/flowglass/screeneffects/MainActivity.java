package com.flowglass.screeneffects;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.animation.ValueAnimator;
import android.view.animation.AccelerateDecelerateInterpolator;


public class MainActivity extends Activity {
    private static final long EFFECT_MS = 300L;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName adminComponent;
    private static final String PREFS = "flowglass_settings";
    private static final String KEY_EFFECT = "effect";
    private static final String[] EFFECTS = {"CRT TV", "Thu nhỏ thành điểm", "Fade Out", "Glitch"};
    private int selected = 0;
    private TextView status;
    private LinearLayout effectList;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(13, 20, 28));
        getWindow().setNavigationBarColor(Color.rgb(13, 20, 28));
        selected = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(KEY_EFFECT, 0);
        devicePolicyManager = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, ScreenEffectsAdminReceiver.class);
        buildUi();
        updateStatus();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(24), dp(20), dp(28));
        root.setBackgroundColor(Color.rgb(13, 20, 28));
        scroll.addView(root);

        TextView brand = text("FLOW GLASS", 13, Color.rgb(155, 214, 229), true);
        root.addView(brand);
        TextView title = text("Screen Effects", 30, Color.WHITE, true);
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2); titleLp.topMargin = dp(5); root.addView(title, titleLp);
        TextView subtitle = text("Hiệu ứng tắt màn hình · kính mờ · 0,3 giây", 14, Color.rgb(185, 198, 209), false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2); subLp.topMargin = dp(6); root.addView(subtitle, subLp);

        LinearLayout glass = panel();
        LinearLayout.LayoutParams panelLp = new LinearLayout.LayoutParams(-1, -2); panelLp.topMargin = dp(22); root.addView(glass, panelLp);
        glass.addView(text("QUYỀN KHÓA MÀN HÌNH", 12, Color.rgb(157, 205, 219), true));
        status = text("Đang kiểm tra…", 15, Color.WHITE, false);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, -2); statusLp.topMargin = dp(8); glass.addView(status, statusLp);
        Button auth = button("Kích hoạt / quản lý quyền khóa màn hình");
        LinearLayout.LayoutParams authLp = new LinearLayout.LayoutParams(-1, dp(48)); authLp.topMargin = dp(14); glass.addView(auth, authLp);
        auth.setOnClickListener(v -> requestDeviceAdmin());

        TextView choose = text("Chọn hiệu ứng", 20, Color.WHITE, true);
        LinearLayout.LayoutParams chooseLp = new LinearLayout.LayoutParams(-1, -2); chooseLp.topMargin = dp(25); root.addView(choose, chooseLp);
        TextView note = text("Chạm để chọn · có thể xem trước trước khi khóa", 13, Color.rgb(175, 189, 201), false);
        LinearLayout.LayoutParams noteLp = new LinearLayout.LayoutParams(-1, -2); noteLp.topMargin = dp(5); root.addView(note, noteLp);
        effectList = new LinearLayout(this); effectList.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams listLp = new LinearLayout.LayoutParams(-1, -2); listLp.topMargin = dp(12); root.addView(effectList, listLp);
        populateEffects();

        Button preview = button("XEM TRƯỚC HIỆU ỨNG");
        LinearLayout.LayoutParams previewLp = new LinearLayout.LayoutParams(-1, dp(52)); previewLp.topMargin = dp(20); root.addView(preview, previewLp);
        preview.setOnClickListener(v -> showAnimation(false));
        Button lock = button("HIỆU ỨNG + KHÓA MÀN HÌNH");
        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(-1, dp(56)); lockLp.topMargin = dp(10); root.addView(lock, lockLp);
        lock.setOnClickListener(v -> startLockFlow());

        TextView disclaimer = text("Không cần Shizuku, ADB thường trực, root hoặc Trợ năng. Android yêu cầu bạn xác nhận quyền Quản trị viên thiết bị để cho phép ứng dụng khóa màn hình. Hiệu ứng 0,3 giây chạy trong ứng dụng trước khi khóa; không thay thế hoạt ảnh hệ thống khi nhấn nút nguồn vật lý.", 12, Color.rgb(166, 181, 193), false);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(-1, -2); dlp.topMargin = dp(18); root.addView(disclaimer, dlp);
        setContentView(scroll);
    }

    private LinearLayout panel() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(17), dp(17), dp(17));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.rgb(30, 43, 54)); bg.setCornerRadius(dp(22)); bg.setStroke(dp(1), Color.rgb(72, 101, 116)); box.setBackground(bg);
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setTextSize(13); b.setTextColor(Color.rgb(14, 28, 36));
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(Color.rgb(177, 220, 229)); bg.setCornerRadius(dp(18)); b.setBackground(bg);
        return b;
    }

    private void populateEffects() {
        effectList.removeAllViews();
        String[] descriptions = {"Co màn hình thành vạch sáng ngang", "Hội tụ về một điểm sáng", "Mờ dần nhẹ nhàng", "Nhiễu số trước khi tắt"};
        for (int i = 0; i < EFFECTS.length; i++) {
            final int index = i;
            LinearLayout card = panel();
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.bottomMargin = dp(9); effectList.addView(card, lp);
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); card.addView(row);
            TextView number = text(String.format(java.util.Locale.US, "%02d", i + 1), 18, Color.rgb(161, 218, 230), true);
            row.addView(number, new LinearLayout.LayoutParams(dp(42), -2));
            LinearLayout labels = new LinearLayout(this); labels.setOrientation(LinearLayout.VERTICAL); row.addView(labels, new LinearLayout.LayoutParams(0, -2, 1));
            labels.addView(text(EFFECTS[i], 16, Color.WHITE, true));
            labels.addView(text(descriptions[i], 12, Color.rgb(183, 197, 207), false));
            TextView selectedLabel = text(i == selected ? "ĐANG CHỌN ✓" : "CHỌN", 11, i == selected ? Color.rgb(161, 218, 230) : Color.LTGRAY, true);
            row.addView(selectedLabel);
            card.setOnClickListener(v -> { selected = index; getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(KEY_EFFECT, selected).apply(); populateEffects(); });
        }
    }

    private boolean isAdminActive() {
        return devicePolicyManager != null && devicePolicyManager.isAdminActive(adminComponent);
    }

    private void updateStatus() {
        if (status == null) return;
        if (isAdminActive()) status.setText("Đã kích hoạt · có quyền khóa màn hình");
        else status.setText("Chưa kích hoạt · cần xác nhận quyền Quản trị viên thiết bị");
    }

    private void requestDeviceAdmin() {
        if (isAdminActive()) {
            toast("Quyền khóa màn hình đã được kích hoạt. Bạn có thể thu hồi trong Cài đặt bảo mật.");
            updateStatus();
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Flow Glass Screen Effects chỉ dùng quyền này để khóa màn hình sau hiệu ứng 0,3 giây. Ứng dụng không xóa dữ liệu, không đặt mật khẩu và không áp dụng chính sách khác.");
        try { startActivity(intent); }
        catch (Exception e) { toast("Không mở được màn hình cấp quyền: " + e.getMessage()); }
    }

    private void startLockFlow() {
        if (!isAdminActive()) {
            toast("Hãy kích hoạt quyền Quản trị viên thiết bị trước.");
            requestDeviceAdmin();
            return;
        }
        showAnimation(true);
    }

    private void showAnimation(boolean lockAfter) {
        final Activity activity = this;
        final EffectView view = new EffectView(this, selected);
        view.setBackgroundColor(Color.BLACK);
        Window w = getWindow();
        View decor = w.getDecorView();
        final int oldVisibility = decor.getSystemUiVisibility();
        decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        setContentView(view);
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(EFFECT_MS); animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(a -> { view.progress = (float)a.getAnimatedValue(); view.invalidate(); });
        animator.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator animation) {
                if (lockAfter) runDeviceAdminLock();
                else { decor.setSystemUiVisibility(oldVisibility); buildUi(); updateStatus(); }
            }
        });
        animator.start();
    }

    private void runDeviceAdminLock() {
        try {
            if (!isAdminActive()) {
                decorRestoreAndShow();
                toast("Quyền Quản trị viên thiết bị chưa được kích hoạt.");
                return;
            }
            devicePolicyManager.lockNow();
        } catch (SecurityException e) {
            decorRestoreAndShow();
            toast("Android từ chối lệnh khóa: " + e.getMessage());
        } catch (Throwable e) {
            decorRestoreAndShow();
            toast("Không khóa được màn hình: " + e.getClass().getSimpleName());
        }
    }

    private void decorRestoreAndShow() {
        runOnUiThread(() -> { buildUi(); updateStatus(); });
    }

    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private static class EffectView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int effect;
        float progress = 0f;
        EffectView(Activity a, int effect) { super(a); this.effect = effect; setLayerType(View.LAYER_TYPE_SOFTWARE, null); }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w = getWidth(), h = getHeight(), cx = w/2f, cy = h/2f;
            float t = Math.max(0f, Math.min(1f, progress));
            p.setColor(Color.BLACK); c.drawColor(Color.BLACK);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL);
            if (effect == 0) {
                float hh = Math.max(1.5f, h * (1f-t) * 0.52f);
                float ww = w * (1f - 0.12f*t);
                p.setShadowLayer(dp(getContext(), 18), 0, 0, Color.rgb(150,220,255));
                c.drawRoundRect(new RectF(cx-ww/2, cy-hh/2, cx+ww/2, cy+hh/2), hh/2, hh/2, p);
                p.clearShadowLayer();
            } else if (effect == 1) {
                float scale = Math.max(0.002f, 1f-t);
                c.save(); c.translate(cx, cy); c.scale(scale, scale);
                p.setColor(Color.WHITE); p.setShadowLayer(dp(getContext(), 20),0,0,Color.rgb(130,215,255));
                c.drawRoundRect(new RectF(-w/2,-h/2,w/2,h/2), dp(getContext(),28), dp(getContext(),28), p);
                p.clearShadowLayer(); c.restore();
            } else if (effect == 2) {
                p.setColor(Color.argb((int)(255*(1f-t)), 255,255,255));
                c.drawRect(0,0,w,h,p);
            } else {
                p.setColor(Color.WHITE);
                int bands = 13;
                for (int i=0;i<bands;i++) {
                    float y = (h/bands)*i;
                    float bandH = Math.max(1f, h/bands*(1f-t));
                    float shift = ((i%2==0)?1:-1) * w * 0.08f * t;
                    p.setAlpha((int)(230*(1f-t)));
                    c.drawRect(shift, y, w-shift, y+bandH, p);
                }
                p.setAlpha(255);
            }
        }
        private static float dp(Activity a, float v) { return v * a.getResources().getDisplayMetrics().density; }
    }
}
