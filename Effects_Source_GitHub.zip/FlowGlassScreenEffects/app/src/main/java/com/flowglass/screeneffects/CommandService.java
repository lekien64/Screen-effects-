package com.flowglass.screeneffects;

import android.os.RemoteException;

/**
 * Shizuku UserService: runs as the Shizuku shell identity.
 * It deliberately performs only the screen-lock key event requested by the app.
 */
public final class CommandService extends ICommandService.Stub {
    public CommandService() {
        super();
    }

    @Override
    public int lockScreen() throws RemoteException {
        try {
            Process process = Runtime.getRuntime().exec(
                    new String[]{"sh", "-c", "input keyevent 26"});
            return process.waitFor();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 130;
        } catch (Exception e) {
            return 1;
        }
    }
}
