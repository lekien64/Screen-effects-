package com.flowglass.screeneffects;

interface ICommandService {
    int lockScreen();
}
